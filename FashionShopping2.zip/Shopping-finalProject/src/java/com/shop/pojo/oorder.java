/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.shop.pojo;

import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author rachealchen
 */
public class oorder {
    
//    private Set<order_product>o_p = new HashSet<>();
    private int o_id;
    private String address;
    private String c_phone;
    private String name;
    
    private seller seller;
    private customer customer;
    
    private Set<order_product> o_p;
    
    public oorder()
    {
        this.address = "";
        this.c_phone="";
        this.customer=new customer();
        this.name="";
        this.o_id=0;
        this.o_p=new HashSet<order_product>();
        this.seller=new seller();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    

    public Set<order_product> getO_p() {
        return o_p;
    }

    public void setO_p(Set<order_product> o_p) {
        this.o_p = o_p;
    }

    public int getO_id() {
        return o_id;
    }

    public void setO_id(int o_id) {
        this.o_id = o_id;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getC_phone() {
        return c_phone;
    }

    public void setC_phone(String c_phone) {
        this.c_phone = c_phone;
    }

    public seller getSeller() {
        return seller;
    }

    public void setSeller(seller seller) {
        this.seller = seller;
    }

    public customer getCustomer() {
        return customer;
    }

    public void setCustomer(customer customer) {
        this.customer = customer;
    }
    
    
}
