/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.shop.pojo;

import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author rachealchen
 */
public class product {
    private int p_id;
    private String p_name;
    private String p_type;
    private String p_price;
    private String p_link;
    
    private Set<order_product> order_product;
    
    public product()
    {
        this.order_product=new HashSet<order_product>();
        this.p_id=0;
        this.p_link="";
        this.p_name="";
        this.p_price="";
        this.p_type="";
    }

    public Set<order_product> getOrder_product() {
        return order_product;
    }

    public void setOrder_product(Set<order_product> order_product) {
        this.order_product = order_product;
    }
    
    
    public int getP_id() {
        return p_id;
    }

    public void setP_id(int p_id) {
        this.p_id = p_id;
    }

    public String getP_name() {
        return p_name;
    }

    public void setP_name(String p_name) {
        this.p_name = p_name;
    }

    public String getP_type() {
        return p_type;
    }

    public void setP_type(String p_type) {
        this.p_type = p_type;
    }

    public String getP_price() {
        return p_price;
    }

    public void setP_price(String p_price) {
        this.p_price = p_price;
    }

    

    public String getP_link() {
        return p_link;
    }

    public void setP_link(String p_link) {
        this.p_link = p_link;
    }
    
}
