/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.shop.pojo;

/**
 *
 * @author rachealchen
 */
public class address {
    
    private int a_id;
    private String address;
    
    private customer customer;
    
    public address()
    {
        this.customer = new customer();
        this.a_id = 0;
        this.address = "";
    }
    
    public address(String address)
    {
        this.address=address;
    }

    public customer getCustomer() {
        return customer;
    }

    public void setCustomer(customer customer) {
        this.customer = customer;
    }

    public int getA_id() {
        return a_id;
    }

    public void setA_id(int a_id) {
        this.a_id = a_id;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

   
    
}
