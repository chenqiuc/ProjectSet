/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.shop.pojo;

import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author rachealchen
 */
public class seller {
    private int s_id;
    private String s_username;
    private String s_password;
    
    private Set<oorder> oorder;
    
    public seller()
    {
        this.oorder = new HashSet<oorder>();
        this.s_id=0;
        this.s_password="";
        this.s_username="";
    }
    
    public seller(String username, String password)
    {
        this.s_password=password;
        this.s_username=username;
    }

    public Set<oorder> getOorder() {
        return oorder;
    }

    public void setOorder(Set<oorder> oorder) {
        this.oorder = oorder;
    }
    

    public int getS_id() {
        return s_id;
    }

    public void setS_id(int s_id) {
        this.s_id = s_id;
    }

    public String getS_username() {
        return s_username;
    }

    public void setS_username(String s_username) {
        this.s_username = s_username;
    }

    public String getS_password() {
        return s_password;
    }

    public void setS_password(String s_password) {
        this.s_password = s_password;
    }

    
    
}
