/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.shop.pojo;

import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author rachealchen
 */
public class customer {
    private int c_id;

    private String c_username;
    private String c_dname;
    private String c_email;
    private String c_password;
    private String c_phone;
    
    private Set<address> address;
    private Set<oorder> oorder;
    
    public customer()
    {
        this.address = new HashSet<address>();
        this.c_dname="";
        this.c_email="";
        this.c_id=0;
        this.c_password="";
        this.c_phone="";
        this.c_username="";
        this.oorder=new HashSet<oorder>();
        
    }
    
    public customer(String username, String password, String dname, String phone, String email)
    {
        this.c_username=username;
        this.c_dname=dname;
        this.c_email=email;
        this.c_password=password;
        this.c_phone=phone;
    }

    public Set<address> getAddress() {
        return address;
    }

    public void setAddress(Set<address> address) {
        this.address = address;
    }

    public Set<oorder> getOorder() {
        return oorder;
    }

    public void setOorder(Set<oorder> oorder) {
        this.oorder = oorder;
    }
    
    public String getC_phone() {
        return c_phone;
    }

    public void setC_phone(String c_phone) {
        this.c_phone = c_phone;
    }
    
    
    public int getC_id() {
        return c_id;
    }

    public void setC_id(int c_id) {
        this.c_id = c_id;
    }

    public String getC_username() {
        return c_username;
    }

    public void setC_username(String c_username) {
        this.c_username = c_username;
    }

    public String getC_dname() {
        return c_dname;
    }

    public void setC_dname(String c_dname) {
        this.c_dname = c_dname;
    }

    public String getC_email() {
        return c_email;
    }

    public void setC_email(String c_email) {
        this.c_email = c_email;
    }

    public String getC_password() {
        return c_password;
    }

    public void setC_password(String c_password) {
        this.c_password = c_password;
    }
    
}
