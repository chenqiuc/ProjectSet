/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.shop.pojo;

/**
 *
 * @author rachealchen
 */
public class order_product {
    
    private int op_id;
    private int p_quantity;
    
    private oorder oorder;
    private product product;
    
    public order_product()
    {
        this.oorder=new oorder();
        this.op_id=0;
        this.p_quantity=0;
        this.oorder = new oorder();
        this.product= new product();
    }

    public oorder getOorder() {
        return oorder;
    }

    public void setOorder(oorder oorder) {
        this.oorder = oorder;
    }

    public product getProduct() {
        return product;
    }

    public void setProduct(product product) {
        this.product = product;
    }
    
    

    public int getOp_id() {
        return op_id;
    }

    public void setOp_id(int op_id) {
        this.op_id = op_id;
    }

    public int getP_quantity() {
        return p_quantity;
    }

    public void setP_quantity(int p_quantity) {
        this.p_quantity = p_quantity;
    }
    
}
