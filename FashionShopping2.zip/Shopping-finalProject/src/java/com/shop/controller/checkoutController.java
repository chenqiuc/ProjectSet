/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.shop.controller;

import com.shop.dao.productDao;
import com.shop.pojo.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;
import org.springframework.web.servlet.view.RedirectView;

/**
 *
 * @author rachealchen
 */
public class checkoutController extends AbstractController {
    
    public checkoutController() {
    }
    
    protected ModelAndView handleRequestInternal(
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        
        System.out.println("enter checkout controller");
        
        ModelAndView mv = null;
        HttpSession session = request.getSession();
        
        System.out.println("checkoutController start");
        
        String name = request.getParameter("name")==null?"-":request.getParameter("name");
//        String id = request.getParameter("id").equalsIgnoreCase("")?"0":request.getParameter("id");
        String option = request.getParameter("option").equalsIgnoreCase("")?"-":request.getParameter("option");
//        HashMap<product, Integer> pp = new HashMap<product, Integer>();
        
        if(name.equalsIgnoreCase("-"))
        {
            mv = new ModelAndView(new RedirectView("/Shopping-finalProject/redirect.htm",false));
        }
        
        
        System.out.println("option get");
        System.out.println("option="+option);
        
        HashMap<String, Integer> previous;
            
        if(session.getAttribute("previous") != null)
        {
            previous = (HashMap<String, Integer>)session.getAttribute("previous");
        }else{
            previous = new HashMap<String, Integer>();
        }
        
        productDao productdao = (productDao)getApplicationContext().getBean("productDAO"); 
        product  p= productdao.searchProductByKeyword(name);
        
        if(option.equalsIgnoreCase("add"))
        {
            if(previous.containsKey(p.getP_name()))
            {
                int number = (previous.get(p.getP_name())+1);
                previous.put(p.getP_name(), number);
                
            } else{
                previous.put(p.getP_name(), 1);
            }
            session.setAttribute("previous", previous);
        }
        
        Set<Map.Entry<String, Integer>> previousEntry = previous.entrySet();
        HashMap<product, Integer> productDisplay = new HashMap<product, Integer>();
        
        int totalPrice = 0;
        int pCount = 0;

            for(Map.Entry<String, Integer> internal : previousEntry){
        
                String keyName = internal.getKey();
//                productDao productdao = (productDao)getApplicationContext().getBean("productDAO");
                p = (product)productdao.searchProductByKeyword(keyName);
                pCount = internal.getValue();
                productDisplay.put(p, pCount);

                totalPrice = totalPrice + (Integer.parseInt(p.getP_price())*pCount);
                 
            }
        
            session.setAttribute("productDisplay", productDisplay);
            session.setAttribute("totalPrice", totalPrice);
            
            mv = new ModelAndView("checkout");
        
//        }

        return mv;
    }
    
}


