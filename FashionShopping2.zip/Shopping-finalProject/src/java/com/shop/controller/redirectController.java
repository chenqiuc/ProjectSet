/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.shop.controller;

import com.shop.dao.*;

import com.shop.pojo.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.hibernate.Hibernate;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

/**
 *
 * @author rachealchen
 */
public class redirectController extends AbstractController {
    
    public redirectController() {
    }
    
    protected ModelAndView handleRequestInternal(
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {

        String header = request.getParameter("header")==null ? "": request.getParameter("header");
        HttpSession session = request.getSession();
         ModelAndView mv = null;
//         String orderOperation = request.getParameter("orderOperation")==null?"":request.getParameter("orderOperation");
        
        if(header.equalsIgnoreCase("profile"))
        {
            
            customer customer = (customer)session.getAttribute("CUSTOMER");
            customerDao loginCustomer = (customerDao) getApplicationContext().getBean("customerDAO");
            addressDao addressdao = (addressDao) getApplicationContext().getBean("addressDAO");
            
            customer c = (customer)loginCustomer.getCustomers(customer.getC_username());

            List<address> addressL = (List<address>)addressdao.getAddress(c.getC_id());

            session.setAttribute("alist", addressL);
            mv = new ModelAndView("profile");
            
                    
        }

        else
        {
             
            customer customer = (customer)session.getAttribute("CUSTOMER");
            customerDao loginCustomer = (customerDao) getApplicationContext().getBean("customerDAO");
            addressDao addressdao = (addressDao) getApplicationContext().getBean("addressDAO");
 
            customer c = (customer)loginCustomer.getCustomers(customer.getC_username());

            List<address> addressL = (List<address>)addressdao.getAddress(c.getC_id());

            session.setAttribute("alist", addressL);
            mv = new ModelAndView("profile");
            
        }

        return mv;
        
    }
    
}
