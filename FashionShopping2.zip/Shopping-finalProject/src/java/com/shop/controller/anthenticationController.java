/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.shop.controller;

import com.shop.dao.*;
import com.shop.pojo.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;
import org.springframework.web.servlet.view.RedirectView;

/**
 *
 * @author rachealchen
 */
public class anthenticationController extends AbstractController {
    
    public anthenticationController() {
    }
    
    protected ModelAndView handleRequestInternal(
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {
//        throw new UnsupportedOperationException("Not yet implemented");
        
        HttpSession session = request.getSession();
        ModelAndView mv = null;

        String option = request.getParameter("option")==null ? "" : request.getParameter("option");
        String role = request.getParameter("role")==null ? "" : request.getParameter("role");;
        
        switch(option)
        {
            case "register":
                
                if(role.equals("customer"))
                {
                    String password = request.getParameter("password");
                    String username = request.getParameter("username");
                    String dname = request.getParameter("dname");
                    String email = request.getParameter("email");
                    String phone = request.getParameter("phone");
                    customerDao user = (customerDao) getApplicationContext().getBean("customerDAO");

                    int regiesterUser = user.addUser(username, password, dname, phone, email);
                    if (regiesterUser == 1) {

                        customer loggeduser = new customer(username, password, dname, phone, email);
                        session.setAttribute("CUSTOMER", loggeduser);
                        int c = 1;
                        session.setAttribute("first", c);
                        mv = new ModelAndView(new RedirectView("/Shopping-finalProject/displayall.htm", false)); 

                    } else {
                        mv = new ModelAndView("failed");
                    }
                    
                }else if(role.equals("seller"))
                {
                    String password = request.getParameter("password");
                    String username = request.getParameter("username");
                    sellerDao user = (sellerDao) getApplicationContext().getBean("sellerDAO");

                    int regiesterSeller = user.addSeller(username, password);
                    if (regiesterSeller == 1) {

                        seller loggedSeller = new seller(username, password);
                        session.setAttribute("SELLER", loggedSeller);
                        mv = new ModelAndView("management");
    
                    } else {
                        mv = new ModelAndView("failed");
                    }
                    
                }else
                {
                    mv = new ModelAndView("choiceFailed");
                }

                
                break;
            case "login":
                if(role.equals("customer"))
                {
                    String userName = request.getParameter("username");
                    String passWord = request.getParameter("password");
                    customerDao loginCustomer = (customerDao) getApplicationContext().getBean("customerDAO");
                    customer loggedCustomer = loginCustomer.authenticateLogin(userName, passWord);
                    if (loggedCustomer == null) {
                        mv = new ModelAndView("failed");

                    } else {
//                        int c = 1;
//                        session.setAttribute("pageNo", c);
                        session.setAttribute("CUSTOMER", loggedCustomer);
                        mv = new ModelAndView(new RedirectView("/Shopping-finalProject/displayall.htm", false));
//                 
                    }
                    
                }else if(role.equals("seller"))
                {
                    String userName = request.getParameter("username");
                    String passWord = request.getParameter("password");
                    sellerDao loginCustomer = (sellerDao) getApplicationContext().getBean("sellerDAO");
                    seller loggedSeller = loginCustomer.authenticateLogin(userName, passWord);
                    if (loggedSeller == null) {
                        mv = new ModelAndView("failed");

                    } else {

                        session.setAttribute("SELLER", loggedSeller);

                        mv = new ModelAndView(new RedirectView("/Shopping-finalProject/manage.htm",false));
                    }
                }else
                {
                    mv = new ModelAndView("choiceFailed");
                }
                break;
            case "logout":
                session.invalidate();
                mv = new ModelAndView(new RedirectView("/Shopping-finalProject/index.htm",false));
                break;
                
                
            default:
                mv = new ModelAndView("register");
                
        }
            
        
        return mv;

    }
    
}
