/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.shop.controller;

import com.shop.dao.*;
import com.shop.pojo.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.validation.BindException;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.SimpleFormController;
import org.springframework.web.servlet.view.RedirectView;

/**
 *
 * @author rachealchen
 */
public class updateController extends SimpleFormController {
    
    public updateController() {
        //Initialize controller properties here or 
        //in the Web Application Context

        setCommandClass(customer.class);
        setCommandName("customer");
        setSuccessView("profile");
        setFormView("failed");
    }
    
    @Override
    protected void doSubmitAction(Object command) throws Exception {
        throw new UnsupportedOperationException("Not yet implemented");
    }

    //Use onSubmit instead of doSubmitAction 
    //when you need access to the Request, Response, or BindException objects
   
    @Override
    protected ModelAndView onSubmit(
            HttpServletRequest request, 
            HttpServletResponse response, 
            Object command, 
            BindException errors) throws Exception {
        
                    HttpSession session = request.getSession();
                    ModelAndView mv = null;
                    String option = request.getParameter("option")==null ? "" : request.getParameter("option");
                    String role = request.getParameter("role");
                    
                    if(option.equalsIgnoreCase("update"))
                    {
                        if(role.equalsIgnoreCase("customer"))
                        {
                            int updateSuccess=0;
                            customer customer = (customer)session.getAttribute("CUSTOMER");
                            String usern = customer.getC_username();
                            String password = request.getParameter("password");
                            String username = request.getParameter("username");
                            String dname = request.getParameter("dname");
                            String email = request.getParameter("email");
                            String phone = request.getParameter("phone");
                            
                            if(password.equalsIgnoreCase("")){password=customer.getC_password();}
                            else{customer.setC_password(password);}
                            if(username.equalsIgnoreCase("")){username=customer.getC_username();}
                            else{customer.setC_username(username);}
                            if(dname.equalsIgnoreCase("")){dname=customer.getC_dname();}
                            else{customer.setC_dname(dname);}
                            if(email.equalsIgnoreCase("")){email=customer.getC_email();}
                            else    {customer.setC_email(email);}
                            if(phone.equalsIgnoreCase("")){phone=customer.getC_phone();}
                            else{customer.setC_phone(phone);}
                            
                            addressDao adddao = (addressDao) getApplicationContext().getBean("addressDAO");
                            
                            customerDao loginCustomer = (customerDao) getApplicationContext().getBean("customerDAO");
                            customer cInternal = loginCustomer.getCustomers(usern);
                            int id = cInternal.getC_id();
                      
                            String[] getAddList = request.getParameterValues("address");
                            
         
                            if(getAddList.length>1)
                            {
                                Set<address> addressList = new HashSet<address>();
                                for(int i = 0;i<getAddList.length-1;i++)
                                {             
                                    address addr = new address();
                                    
                                    addr.setAddress(getAddList[i]);
                                    addr.setCustomer(customer);
                                    adddao.addAddress22(addr);
                                    addressList.add(addr);
                                    
                                    System.out.println(getAddList[i]);             
                                }
                                customer.setAddress(addressList);
                                loginCustomer.updateCustomer(customer);
                                
                                session.setAttribute("CUSTOMER",customer);
//                   
                                mv = new ModelAndView(new RedirectView("/Shopping-finalProject/redirect.htm", false)); 

                       
                            }else
                            {     
//                         
                                updateSuccess = loginCustomer.updateCustomer(customer);
                                
                                if (updateSuccess == 0) {
                                    mv = new ModelAndView("failed");

                                } else {
                            
                                    session.setAttribute("CUSTOMER",customer);
                //           
                                    mv = new ModelAndView(new RedirectView("/Shopping-finalProject/redirect.htm", false));
                                }
                            }
                            
                            
                        }
                    }
      
        return mv;
    }
     
}
