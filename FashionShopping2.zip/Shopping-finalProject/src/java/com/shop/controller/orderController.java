/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.shop.controller;

import com.shop.dao.addressDao;
import com.shop.dao.customerDao;
import com.shop.dao.orderDao;
import com.shop.dao.orderproductDao;
import com.shop.dao.productDao;
import com.shop.dao.sellerDao;
import com.shop.pojo.address;
import com.shop.pojo.customer;
import com.shop.pojo.oorder;
import com.shop.pojo.order_product;
import com.shop.pojo.product;
import com.shop.pojo.seller;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;
import org.springframework.web.servlet.view.RedirectView;

/**
 *
 * @author rachealchen
 */
public class orderController extends AbstractController {
    
    public orderController() {
    }
    
    protected ModelAndView handleRequestInternal(
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {
//        throw new UnsupportedOperationException("Not yet implemented");
//            orderOperation=confirm;

            ModelAndView mv = null;
            HttpSession session = request.getSession();

            String orderOperation = request.getParameter("orderOperation")==null?"":request.getParameter("orderOperation");
            
            if(orderOperation.equalsIgnoreCase("confirm"))
            {
                customer customer = (customer)session.getAttribute("CUSTOMER");
                customerDao loginCustomer = (customerDao) getApplicationContext().getBean("customerDAO");
                addressDao addressdao = (addressDao) getApplicationContext().getBean("addressDAO");

                customer c = (customer)loginCustomer.getCustomers(customer.getC_username());

                List<address> addressL = (List<address>)addressdao.getAddress(c.getC_id());

                session.setAttribute("alist", addressL);
                mv = new ModelAndView("orderConfirm");
               
//                mv = new ModelAndView(new RedirectView("/Shopping-finalProject/redirect.htm", false));
                        
                
            }else if(orderOperation.equalsIgnoreCase("orderIt"))
            {
                customerDao loginCustomer = (customerDao) getApplicationContext().getBean("customerDAO");
                addressDao addressdao = (addressDao) getApplicationContext().getBean("addressDAO");
                orderDao orderdao = (orderDao) getApplicationContext().getBean("orderDAO");
                orderproductDao opdao = (orderproductDao) getApplicationContext().getBean("orderproductDAO");
                sellerDao sellerdao = (sellerDao) getApplicationContext().getBean("sellerDAO");
                productDao productdao = (productDao)getApplicationContext().getBean("productDAO");
                
                
                String orderaddress = request.getParameter("orderaddress")==null?"":request.getParameter("orderaddress");
                session.setAttribute("orderaddress", orderaddress);
                String phone = request.getParameter("phone")==null?"":request.getParameter("phone");
                String dname = request.getParameter("dname")==null?"":request.getParameter("dname");
                customer customer = (customer)session.getAttribute("CUSTOMER");
                seller seller = (seller)sellerdao.getSeller("s1");
                
                oorder order = new oorder();
                order.setAddress(orderaddress);
                order.setC_phone(phone);
                order.setName(dname);
                order.setCustomer(customer);
                order.setSeller(seller);
                
                HashMap<product, Integer> productDisplay;
                
                if(session.getAttribute("productDisplay") != null)
                {
                    productDisplay = (HashMap<product, Integer>)session.getAttribute("productDisplay");
                }else{
                    productDisplay = new HashMap<product, Integer>();
                }
                
                Set<Map.Entry<product, Integer>> entry = productDisplay.entrySet();
                
                for(Map.Entry<product, Integer> internal : entry)
                {
                    product product = productdao.searchProductByKeyword(internal.getKey().getP_name());
                    order_product op = new order_product();
                    op.setOorder(order);
                    System.out.println("op-order add successful! ");
                    op.setProduct(internal.getKey());
                    System.out.println("op-product add successful! ");
                    op.setP_quantity(internal.getValue());
                    System.out.println("op-quantity add successful! ");
                    
                    Set<order_product> setop = new HashSet<order_product>();
//                    
                        setop.add(op);
//                    
                    order.setO_p(setop);
                    
                    
                   Set<order_product> setop_p = new HashSet<order_product>();
                   setop_p.add(op);
                   product.setOrder_product(setop_p);
//                   
                    
//                    update Product
                    int k = 0;
                    k = productdao.updateProduct(product);
                    if(k!=0)
                    {
                        System.out.println("product add successful! ");
                        System.out.println("product name = "+product.getP_name());
                    }else
                    {
                        System.out.println("product add failed>>> ");
                    }
                    
//                    add order_product
                    int i = 0;
                    i = opdao.addOrderProduct(op);
                    if(i!=0)
                    {
                        System.out.println("op add successful! ");
                        System.out.println("order product --> product quantitiy="+op.getP_quantity());
                    }else
                    {
                        System.out.println("op add failed>>> ");
                    }
                    
                }
                
//                add order
                int h = 0;
                h = orderdao.addOrder(order);
                if(h!=0)
                {
                    System.out.println("order add successful! ");
                }else
                {
                    System.out.println("order add failed>>> ");
                }
                session.removeAttribute("productDisplay");
                session.removeAttribute("previous");
                mv = new ModelAndView("orderFinish");
                
            }
            return mv;
    }
    
}
