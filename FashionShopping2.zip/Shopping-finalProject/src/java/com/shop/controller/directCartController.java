/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.shop.controller;

import com.shop.dao.productDao;
import com.shop.pojo.product;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

/**
 *
 * @author rachealchen
 */
public class directCartController extends AbstractController {

    public directCartController() {
    }

    protected ModelAndView handleRequestInternal(
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {

//        
        ModelAndView mv = null;
        HttpSession session = request.getSession();

        String operation = request.getParameter("operation") == null ? "" : request.getParameter("operation");
        String pname = request.getParameter("pname") == null ? "" : request.getParameter("pname");
        productDao productdao = (productDao) getApplicationContext().getBean("productDAO");

        if (operation.equalsIgnoreCase("delete")) {
            HashMap<product, Integer> productDisplay;
            if (session.getAttribute("productDisplay") != null) {
                productDisplay = (HashMap<product, Integer>) session.getAttribute("productDisplay");
            } else {
                productDisplay = new HashMap<product, Integer>();
            }

            Set<Map.Entry<product, Integer>> entry = productDisplay.entrySet();
//           
            int totalPrice = Integer.parseInt(String.valueOf(session.getAttribute("totalPrice")));
            int pCount = 0;

            for (Map.Entry<product, Integer> internal : entry) {

//                  
                product p2 = (product) productdao.searchProductByKeyword(pname);
                product p = internal.getKey();
                if (p2.getP_name().equalsIgnoreCase(p.getP_name())) {
                    pCount = internal.getValue();
                    if ((pCount - 1) == 0) {
                        productDisplay.remove(p);
                        totalPrice = totalPrice - (Integer.parseInt(p.getP_price()));

                    } else {
                        productDisplay.put(p, pCount - 1);
                        totalPrice = totalPrice - (Integer.parseInt(p.getP_price()));
                    }

                }

                //      
            }

            session.setAttribute("productDisplay", productDisplay);
            session.setAttribute("totalPrice", totalPrice);

        } else if (operation.equalsIgnoreCase("add")) {
            HashMap<product, Integer> productDisplay;
            if (session.getAttribute("productDisplay") != null) {
                productDisplay = (HashMap<product, Integer>) session.getAttribute("productDisplay");
            } else {
                productDisplay = new HashMap<product, Integer>();
            }

            Set<Map.Entry<product, Integer>> entry = productDisplay.entrySet();
//            HashMap<product, Integer> productDisplay = new HashMap<product, Integer>();

            int totalPrice = Integer.parseInt(String.valueOf(session.getAttribute("totalPrice")));
            int pCount = 0;

            for (Map.Entry<product, Integer> internal : entry) {

                product p2 = (product) productdao.searchProductByKeyword(pname);
                product p = internal.getKey();
                if (p2.getP_name().equalsIgnoreCase(p.getP_name())) {
                    pCount = internal.getValue();

                    productDisplay.put(p, pCount + 1);
                    totalPrice = totalPrice + (Integer.parseInt(p.getP_price()));

                }

            }

            session.setAttribute("productDisplay", productDisplay);
            session.setAttribute("totalPrice", totalPrice);
        }

        mv = new ModelAndView("checkout");

        return mv;

    }

}
