/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.shop.controller;

import com.shop.dao.productDao;
import com.shop.pojo.product;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

/**
 *
 * @author rachealchen
 */
public class goSingleController extends AbstractController {
    
    public goSingleController() {
    }
    
    protected ModelAndView handleRequestInternal(
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {
//        throw new UnsupportedOperationException("Not yet implemented");
        ModelAndView mv = null;
        HttpSession session = request.getSession();
        

        String productName = request.getParameter("productName")==null?"":request.getParameter("productName");
        
        productDao pdao = (productDao)getApplicationContext().getBean("productDAO");
        
        product product = pdao.searchProductByKeyword(productName);
        
        session.setAttribute("productTem", product);
        mv = new ModelAndView("single");   
        return mv;
    }
}