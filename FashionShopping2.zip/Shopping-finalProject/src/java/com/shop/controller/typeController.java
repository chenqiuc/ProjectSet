/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.shop.controller;

import com.shop.dao.productDao;
import com.shop.pojo.product;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

/**
 *
 * @author rachealchen
 */
public class typeController extends AbstractController {
    
    public typeController() {
    }
    
    protected ModelAndView handleRequestInternal(
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {
//        throw new UnsupportedOperationException("Not yet implemented");
         ModelAndView mv = null;
         HttpSession session = request.getSession();


        String type = request.getParameter("type")==null?"":request.getParameter("type");
        productDao pdao = (productDao)getApplicationContext().getBean("productDAO");
        
        String pageNo = request.getParameter("pageNo")==null?"1":request.getParameter("pageNo");    
        
        List<product> pro = pdao.getProductByType(type,Integer.parseInt(pageNo));
        
        ArrayList<ArrayList<product>> totalProList = new ArrayList<ArrayList<product>>();
//            List<product> pro = new ArrayList<product>();
            
//            pro=pdao.getProForPage(Integer.parseInt(pageNo));
//            pro = pdao.getProductAll();
            
            int indexTrans = 0;
            if(pro.size()>=3)
            {
                for(int i =0;i<((int)(pro.size()/3));i++)
                {
                    ArrayList<product> proListInternal = new ArrayList<product>();
                    for(int h =0;h<3;h++)
                    { 
                        proListInternal.add(pro.get((3*indexTrans)+h));

                        System.out.println((3*indexTrans)+h);
                    }
                    totalProList.add(proListInternal);
                   indexTrans = indexTrans+1;

                }
            }else
            {
                totalProList.add((ArrayList<product>) pro);
            }
            
            session.setAttribute("totalProList", totalProList);
             System.out.println("totalProList="+totalProList);

            mv = new ModelAndView("shoppingStart");
            return mv;
        
    }
    
}
