/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.shop.dao;


import com.shop.pojo.customer;
import com.shop.pojo.order_product;
import com.shop.pojo.product;
import java.util.ArrayList;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;

/**
 *
 * @author rachealchen
 */
public class productDao {
    
    public productDao(){}
    
    private static final SessionFactory sf = new  Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
    private Session session = null;
    private Session getSession(){
        if (session == null || !session.isOpen()){
            session = sf.openSession();
        }
        return session;
    }
   
    
    private void beginTransaction(){
        getSession().beginTransaction();
    }
    
    private void commit(){
        getSession().getTransaction().commit();
    }
    
    
    private void close(){
        if (session !=null)
        {
            getSession().close();
        }
    }
    
    private void rollbackTransaction(){
        getSession().getTransaction().rollback();
    }

    
    public int updateProduct(product product)
    {
        int updateSuccess = 0;
        try {
            beginTransaction();
            getSession().update(product);
            commit();
            updateSuccess = 1;
        } catch (HibernateException e) {
            e.printStackTrace();
            rollbackTransaction();
        } 
        finally {
            close();
        }

        return updateSuccess;
        
    }
    
    public int addProduct(product product) {
        int registerSuccess = 0;
        try {

            beginTransaction();
            getSession().save(product);
            commit();
            registerSuccess = 1;
        } catch (HibernateException e) {
            e.printStackTrace();
            rollbackTransaction();
        } 
        finally {
            close();
        }

        return registerSuccess;

    }

    public List<product> getProductByType(String p_type, int pageNo) {

        List<product> matchedProduct = new ArrayList<product>() ;
        try {
            beginTransaction();
            Query q= getSession().createQuery("from product where p_type= :type");
            q.setString("type", p_type);
            int first = (6*(pageNo-1))+1;
//            System.out.println("first = "+first);
            q.setFirstResult(first);
//            System.out.println("first result settled" );
            q.setMaxResults(first+6);
//            System.out.println("max result settled");
            matchedProduct = q.list();
//            System.out.println("q.list() returned size = "+matchedProduct.size());
            if(matchedProduct.size()>6)
            {
                List<product> productinter = new ArrayList<product>();
                for(int i =0;i<6;i++)
                {
                    productinter.add(matchedProduct.get(i));
                }
                matchedProduct.clear();
                for(int h =0;h<6;h++)
                {
                    matchedProduct.add(productinter.get(h));
                }
                
            }
           
            matchedProduct = q.list();
            commit();
        } catch (HibernateException e) {
            e.printStackTrace();
            rollbackTransaction();
        } 
        finally {
            close();
        }
        return matchedProduct;
    }
    
    public List<product> getProductAll() {

        List<product> matchedProduct = new ArrayList<product>() ;
        try {
            beginTransaction();

            Criteria crit = getSession().createCriteria(product.class);

            matchedProduct = (List<product>)crit.list();
            commit();
        } catch (HibernateException e) {
            e.printStackTrace();
            rollbackTransaction();
        } 
        finally {
            close();
        }
        return matchedProduct;
    }
    
    public List<product> searchProductByType(String type) {
        List<product> productList = new ArrayList<product>();
        try {
            beginTransaction();
            
            Criteria crit = getSession().createCriteria(product.class);
            crit.add(Restrictions.ilike("p_type", type, MatchMode.ANYWHERE));
            productList = crit.list();
            commit();
        } catch (HibernateException e) {
            e.printStackTrace();
            rollbackTransaction();
        }  catch (Exception e){
           return productList;
        }finally {
            close();
        }
        return productList;
    }
    
    public List<product> searchProductById(int id) {
        List<product> productList = new ArrayList<product>();
        try {
            beginTransaction();
            
            Criteria crit = getSession().createCriteria(product.class);
            crit.add(Restrictions.eq("p_id", String.valueOf(id)));
            productList = crit.list();
            System.out.println("p_name="+productList.get(0).getP_name());
            commit();
        } catch (HibernateException e) {
            e.printStackTrace();
            rollbackTransaction();
        }  catch (Exception e){
           return productList;
        }finally {
            close();
        }
        return productList;
    }
    
    public product searchProductByKeyword(String search) {
        product product_keyword = new product();
        try {
            beginTransaction();
            System.out.println("beginTransaction");
            
            Criteria crit = getSession().createCriteria(product.class);
            System.out.println("createCriteria");
            Criterion c1 = Restrictions.ilike("p_name", search, MatchMode.EXACT);
            System.out.println("Criteria create restriction");

            Disjunction disjunction = Restrictions.disjunction( );
            System.out.println("create disjuction");
            disjunction.add(c1);
            System.out.println("disjunction add 01");

            crit.add(disjunction);
            System.out.println("criteria add disjunction");

            product_keyword = (product)crit.uniqueResult();
            System.out.println("product have gotton");

            commit();
            System.out.println("commit");
        } catch (HibernateException e) {
            e.printStackTrace();
            rollbackTransaction();
        }  catch (Exception e){
           return product_keyword;
        }finally {
            close();
        }
        return product_keyword;
    }
    
    
    public  List<product> getProForPage(int pageNo) {
       List<product> matchedProduct = new ArrayList<product>() ;
       
        try {
            beginTransaction();
//            System.out.println("beginTransaction");
            Query q= getSession().createQuery("from product");
//            System.out.println("begin query");
            int first = (6*(pageNo-1))+1;
//            System.out.println("first = "+first);
            q.setFirstResult(first);
//            System.out.println("first result settled" );
            q.setMaxResults(first+6);
//            System.out.println("max result settled");
            matchedProduct = q.list();
//            System.out.println("q.list() returned size = "+matchedProduct.size());
            if(matchedProduct.size()>6)
            {
                List<product> productinter = new ArrayList<product>();
                for(int i =0;i<6;i++)
                {
                    productinter.add(matchedProduct.get(i));
                }
                matchedProduct.clear();
                for(int h =0;h<6;h++)
                {
                    matchedProduct.add(productinter.get(h));
                }
                
            }
            System.out.println("q.list() change size = "+matchedProduct.size());
            commit();
            System.out.println("commit");
        } catch (HibernateException e) {
            e.printStackTrace();
            rollbackTransaction();
        } 
        finally {
            close();
        }
        return matchedProduct;
    }
//    
//   
    
}
