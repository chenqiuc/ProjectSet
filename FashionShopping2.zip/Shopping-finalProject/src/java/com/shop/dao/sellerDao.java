/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.shop.dao;

import com.shop.pojo.seller;
import java.util.ArrayList;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 *
 * @author rachealchen
 */
public class sellerDao {
    
    public sellerDao(){}
    
    private static final SessionFactory sf = new  Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
    private Session session = null;
    private Session getSession(){
        if (session == null || !session.isOpen()){
            session = sf.openSession();
        }
        return session;
    }
   
    
    private void beginTransaction(){
        getSession().beginTransaction();
    }
    
    private void commit(){
        getSession().getTransaction().commit();
    }
    
    
    private void close(){
        if (session !=null)
        {
            getSession().close();
        }
    }
    
    private void rollbackTransaction(){
        getSession().getTransaction().rollback();
    }

    public seller authenticateLogin(String username, String password) {
        seller loggedInUser = null;
        try {
            beginTransaction();
            Query q= getSession().createQuery("from seller where s_username= :username AND s_password= :password");
            q.setString("username", username);
            q.setString("password", password);
            loggedInUser = (seller)q.uniqueResult();
            commit();
        } catch (HibernateException e) {
            e.printStackTrace();
            rollbackTransaction();
        } 
        finally {
            close();
        }
        return loggedInUser;
    }

    public seller getSeller(String sellerName) {
        seller matchedUsers = new seller();
        try {
            beginTransaction();
            Query q= getSession().createQuery("from seller where s_username= :username");
            q.setString("username", sellerName);
            matchedUsers = (seller) q.uniqueResult();
            commit();
        } catch (HibernateException e) {
            e.printStackTrace();
            rollbackTransaction();
        } 
        finally {
            close();
        }
        return matchedUsers;
    }

    public int addSeller(String userName, String password) {
        seller newUser = null;
        int registerSuccess = 0;
        try {
            newUser = new seller();
            newUser.setS_username(userName);
            newUser.setS_password(password);
            beginTransaction();
            getSession().save(newUser);
            commit();
            registerSuccess = 1;
        } catch (HibernateException e) {
            e.printStackTrace();
            rollbackTransaction();
        } 
        finally {
            close();
        }

        return registerSuccess;

    }
    

    
}
