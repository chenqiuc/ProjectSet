/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.shop.dao;


import com.shop.pojo.address;
import java.util.ArrayList;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 *
 * @author rachealchen
 */
public class addressDao {
    
     public addressDao(){}
    
    private static final SessionFactory sf = new  Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
    private Session session = null;
    private Session getSession(){
        if (session == null || !session.isOpen()){
            session = sf.openSession();
        }
        return session;
    }
   
    
    private void beginTransaction(){
        getSession().beginTransaction();
    }
    
    private void commit(){
        getSession().getTransaction().commit();
    }
    
    
    private void close(){
        if (session !=null)
        {
            getSession().close();
        }
    }
    
    private void rollbackTransaction(){
        getSession().getTransaction().rollback();
    }


    public List<address> getAddress(int h) {
        List<address> matchedUsers = new ArrayList<address>() ;
        try {
            beginTransaction();
            Query q= getSession().createQuery("from address where fk_customer_id = :i");
            q.setInteger("i", h);
            matchedUsers = q.list();
            commit();
        } catch (HibernateException e) {
            e.printStackTrace();
            rollbackTransaction();
        } 
        finally {
            close();
        }
        return matchedUsers;
    }

    public int addAddress(String address) {
        address newAddress = null;
        int registerSuccess = 0;
        try {
            newAddress = new address();
            newAddress.setAddress(address);
            beginTransaction();
            getSession().save(newAddress);
            commit();
            registerSuccess = 1;
        } catch (HibernateException e) {
            e.printStackTrace();
            rollbackTransaction();
        } 
        finally {
            close();
        }

        return registerSuccess;

    }
    
    
     public int addAddress22(address address) {
//        address newAddress = null;
        int registerSuccess = 0;
        try {
//            newAddress = new address();
//            newAddress.setAddress(address);
            beginTransaction();
            getSession().save(address);
            commit();
            registerSuccess = 1;
        } catch (HibernateException e) {
            e.printStackTrace();
            rollbackTransaction();
        } 
        finally {
            close();
        }

        return registerSuccess;

    }
    
    
    
    public int updateAddress(String address)
    {
        address Addresss = null;
        int updateSuccess = 0;
        try {
            beginTransaction();
            Addresss = (address)session.get(address.class, 1);
            Addresss.setAddress(address);
        
//            getSession().update(customer);
            commit();
            updateSuccess = 1;
        } catch (HibernateException e) {
            e.printStackTrace();
            rollbackTransaction();
        } 
        finally {
            close();
        }

        return updateSuccess;
        
    }
    
    public List<address> getAviaC()
    {
//        String sql = "";
        List<address> matchedAddress = new ArrayList<address>() ;
        try {
            beginTransaction();
            Query q= getSession().createQuery("Select a.address from 6250shoppingFinal.address as a inner join 6250shoppingFinal.customer as c on a.fk_customer_id = c.c_id where a.fk_customer_id = 1");
//            q.setInteger("i", h);
            matchedAddress = q.list();
            commit();
        } catch (HibernateException e) {
            e.printStackTrace();
            rollbackTransaction();
        } 
        finally {
            close();
        }
        return matchedAddress;
    
        
        
    }
    
}
