/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.shop.dao;

import com.shop.pojo.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 *
 * @author rachealchen
 */
public class customerDao {
    
     public customerDao(){}
    
    
    private static final SessionFactory sf = new  Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
    private Session session = null;
    private Session getSession(){
        if (session == null || !session.isOpen()){
            session = sf.openSession();
        }
        return session;
    }
   
    
    private void beginTransaction(){
        getSession().beginTransaction();
    }
    
    private void commit(){
        getSession().getTransaction().commit();
    }
    
    
    private void close(){
        if (session !=null)
        {
            getSession().close();
        }
    }
    
    private void rollbackTransaction(){
        getSession().getTransaction().rollback();
    }

    public customer authenticateLogin(String username, String password) {
        customer loggedInUser = null;
        try {
            beginTransaction();
            Query q= getSession().createQuery("from customer where c_username= :username AND c_password= :password");
            q.setString("username", username);
            q.setString("password", password);
            loggedInUser = (customer)q.uniqueResult();
            commit();
        } catch (HibernateException e) {
            e.printStackTrace();
            rollbackTransaction();
        } 
        finally {
            close();
        }
        return loggedInUser;
    }

    public customer getCustomers(String searchusername) {
//        List<customer> matchedUsers = new ArrayList<customer>() ;
        customer matchedUsers = new customer() ;
        try {
            beginTransaction();
            Query q= getSession().createQuery("from customer where c_username= :username");
            q.setString("username", searchusername);
            matchedUsers = (customer)q.uniqueResult();
            commit();
        } catch (HibernateException e) {
            e.printStackTrace();
            rollbackTransaction();
        } 
        finally {
            close();
        }
        return matchedUsers;
    }

    public int addUser(String userName, String password, String dname, String phone, String email) {
        customer newUser = null;
        int registerSuccess = 0;
        try {
            newUser = new customer();
            newUser.setC_username(userName);
            newUser.setC_password(password);
            newUser.setC_email(email);
            newUser.setC_dname(dname);
            newUser.setC_phone(phone);
            beginTransaction();
            getSession().save(newUser);
            commit();
            registerSuccess = 1;
        } catch (HibernateException e) {
            e.printStackTrace();
            rollbackTransaction();
        } 
        finally {
            close();
        }

        return registerSuccess;

    }
    
     public int updateCustomer(customer cus)
    {
        int updateSuccess = 0;
        try {
            beginTransaction();
            getSession().update(cus);
            commit();
            updateSuccess = 1;
        } catch (HibernateException e) {
            e.printStackTrace();
            rollbackTransaction();
        } 
        finally {
            close();
        }

        return updateSuccess;
        
    }
    
    
    
}
