/**
 * smartApp endpoint route definitions.
 */

'use strict';
module.exports = function (app) {
  const smartAppController = require('../controllers/smartApp-controllers');
    
  // app routes for search and create
  app.route('/userdata')
    .get(smartAppController.getSmartAppList)
    .post(smartAppController.addSmartApp)

  // app routes for delete and update
  app.route('/userdata/smartapps/:appId')
    .delete(smartAppController.deleteSmartApp)
    .put(smartAppController.updateSmartApp);
  
  // user login
  app.route('/users')
    .post(smartAppController.userLogin)

  // user signup
  app.route('/users/user')
    .post(smartAppController.userSignup)

  };