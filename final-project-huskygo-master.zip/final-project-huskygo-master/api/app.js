'use strict';
module.exports = function (app) {
  //initialize models
  let smartAppModels = require('./models/smartApp-models');

  //initialize routes
  let smartAppRoutes = require('./routes/smartApp-routes');
  smartAppRoutes(app);
};