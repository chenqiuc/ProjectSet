const mongoose = require('mongoose');
const Schema = mongoose.Schema;

/**
 * Mongoose schema for user object
 */
let UserSchema = new Schema({
    /**
     * email
     */
    email: {
      type: String,
      required: "email is required"
    },
    /**
     * password
     */
    password: {
      type: String,
      required: "password is required",
    },

  }, {
    versionKey: false
  }
);

module.exports = UserSchema;