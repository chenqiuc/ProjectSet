const mongoose = require('mongoose');
const Schema = mongoose.Schema;

/**
 * Mongoose schema for smartApp object
 */
let SmartAppSchema = new Schema({
    /**
     * name of the app
     */
    useremail: {
      type: String,
      required: "useremail is required"
    },
    /**
     * name of the app
     */
    smartapps: {
      type: Array,
      required: "smartapps is required",
    },

    // /**
    //  *  room of the app
    //  */
    // room: {
    //   type: String,
    //   required: "room is required"
    // },
    // /**
    //  *  status of the app
    //  */
    // status: {
    //   type: Boolean,
    //   required: "status is required"
    // },
  }, {
    versionKey: false
  }
  // , {
  //   collection: 'smart_apps'
  // }
);

// module.exports = mongoose.model('smartapps', SmartAppSchema);
module.exports = SmartAppSchema;



