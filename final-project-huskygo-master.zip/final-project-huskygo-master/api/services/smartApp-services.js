/**
 * services for smartApp operations
 */

'use strict';
const mongoose = require('mongoose');
const userSchema = require('../models/user-models');
const smartAppSchema = require('../models/smartApp-models');
const smartapps = mongoose.model('smartapps', smartAppSchema);
const users = mongoose.model('users', userSchema);

/**
 * throws error if error object is present
 *
 * @param {Object} error {Error object}
 */
let throwError = function (error) {
  if (error) {
    throw Error(error);
  }
};

/**
 * Returns an array of sticky object matching the search parameters
 *
 * @param {Object} params {Search parameters}
 * @param {function} callback {Success callback function}
 */
exports.searchDB = (params, callback) => {
  let resultCallback = (err, smartAppsList) => {
    throwError(err);
    callback(err, smartAppsList);
  };

  smartapps.find(params, resultCallback);
};


exports.addApp = (params, callback) => {
  let resultCallback = (err, res) => {
    throwError(err);
    callback(err, res);
  };
  let useremail = params.useremail;
  let tempApp = params.app;

  smartapps.findOneAndUpdate({
    useremail: useremail
  }, {
    $push: {
      smartapps: tempApp
    }
  }, (err, res) => {
    if (err) {
      throw Error(err);
    } else if (res) {
      console.log(res)
      smartapps.find({
        useremail: useremail
      }, resultCallback)
    }


  });
}


exports.deleteApp = (params, callback) => {
  let resultCallback = (err, res) => {
    throwError(err);
    console.log(res);
    callback(err, res);
  };
  let useremail = params.useremail;
  let id = params.id;

  smartapps.update({
    useremail: useremail
  }, {
    $pull: {
      smartapps: {
        id: id
      }
    }
  }, (err, res) => {
    if (err) {
      throw Error(err);
    } else if (res) {
      console.log(res)
      smartapps.find({
        useremail: useremail
      }, resultCallback)
    }
  });
}

exports.updateApp = (params, callback) => {
  let resultCallback = (err, res) => {
    throwError(err);
    console.log(res);
    callback(err, res);
  };
  let useremail = params.useremail;
  let id = params.id;
  let app = params.smartApp;
  let config = app.configuration;
  console.log(config)

  smartapps.update({
    "useremail": useremail,
    "smartapps.id": id
  }, {
    $set: {
      "smartapps.$": app
    }
  }, (err, res) => {
    if (err) {
      throw Error(err);
    } else if (res) {
      console.log(res)
      smartapps.find({
        useremail: useremail
      }, resultCallback)
    }
  });
}

exports.searchUser = (params, callback) => {
  let resultCallback = (err, res) => {
    throwError(err);
    callback(err, res)
  };
  users.find({
    email: params.email
  }, resultCallback);
};

exports.createUser = (params, callback) => {
  let resultCallback = (err, res) => {
    throwError(err);
    callback(err, res);
  };

  console.log(params);
  users.find({
    email: params.email
  }, (err, res) => {
    if (err) {
      throw Error(err);
    } else {
      if (res.length > 0) {
        res.status(500).json('Email Exist')
      } else {
        let newUser = new users({email: params.email, password: params.password});
        console.log(newUser)
        newUser.save((resultCallback));
      }
    }
  });
}
