/**
 * controller for smartApp endpoints
 */

'use strict';

//import smartApp service
const smartAppService = require('../services/smartApp-services');
const mongoose = require('mongoose');
/**
 * returns a list of smartApps in JSON based on the search parameters
 *
 * @param {request} {HTTP request object}
 * @param {response} {HTTP response object}
 */

exports.getSmartAppList = (request, response) => {
  let callback = (err, smartApps) => {
    if (err) {
      response.status(500);
      response.err(err);
    } else {
      response.status(200);
      response.json(smartApps);
    }
  };
  // let header = request.get('token');
  // console.log(header);
  let param = {
    useremail: 'admin@husky.neu.edu'
  };
  smartAppService.searchDB(param, callback);
};


exports.addSmartApp = (request, response) => {
  let callback = (err, smartApps) => {
    if (err) {
      response.status(500);
      response.err(err);
    } else {
      response.status(200);
      response.json(smartApps);
    }
  };
  // let header = request.get('token');
  // console.log(header);
  let tempApp = request.body.smartApp;
  tempApp.id = new mongoose.Types.ObjectId();
  console.log(tempApp);
  let param = {
    useremail: 'admin@husky.neu.edu',
    app: tempApp
  };
  smartAppService.addApp(param, callback);
};


exports.deleteSmartApp = (request, response) => {
  let callback = (err, res) => {
    if (err) {
      response.status(500);
      response.err(err);
    } else {
      response.status(200);
      response.json(res);
    }
  };

  const mongoose = require('mongoose');
  let objectId = mongoose.Types.ObjectId(request.params.appId);
  let params = {
    useremail: 'admin@husky.neu.edu',
    id: objectId
  };
  smartAppService.deleteApp(params, callback)
}


exports.updateSmartApp = (request, response) => {
  let callback = (err, res) => {
    if (err) {
      response.status(500);
      response.err(err);
    } else {
      response.status(200);
      response.json(res);
    }
  };

  // let tempId = request.params.appId; 
  let objectId = mongoose.Types.ObjectId(request.params.appId);
  let tempApp = request.body.smartApp;
  tempApp.id = objectId;
  console.log('body:');
  console.log(tempApp);
  let params = {
    useremail: 'admin@husky.neu.edu',
    id: objectId,
    smartApp: tempApp
  };
  smartAppService.updateApp(params, callback)
}


exports.userLogin = (request, response) => {
  let callback = (err, res) => {
    if (err) {
      console.log(err);
      response.status(401).json('AuthFailed');
      response.err(err);
    } else {
      console.log(res);
      if (res.length <= 0) {
        response.status(401).json('AuthFailed');
      } else {
        if (res[0].password === request.body.password) {
          response.status(200);
          response.json({
            res: res,
            message: 'login success'
          });
        } else {
          response.status(401).json('Auth Failed')
        }

      }

    }
  };
  let param = request.body;
  smartAppService.searchUser(param, callback);
};

exports.userSignup = (request, response) => {
  let callback = (err, res) => {
    if (err) {
      response.status(500).json('SignUp Failed');
      response.err(err);
    } else {
      response.status(200);
      response.json({
        res: res,
        message: 'signup success'
      });
    }
  };
  let param = request.body;
  smartAppService.createUser(param, callback);
};