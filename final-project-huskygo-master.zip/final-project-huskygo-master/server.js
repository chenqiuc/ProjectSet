const express = require('express'),
  app = express(),
  port = process.env.PORT || 7777,
  mongoose = require('mongoose'), //created model loading here
  bodyParser = require('body-parser');

/**
 * connect local mongodb with url
 */
// mongoose.connect('mongodb://localhost:27017/smartAppDB', {

/**
 * connect cloud mongodb with url
 */
let url = 'mongodb://admin:admin@info6150-shard-00-00-jcyfe.mongodb.net:27017,info6150-shard-00-01-jcyfe.mongodb.net:27017,info6150-shard-00-02-jcyfe.mongodb.net:27017/smartappdb?ssl=true&replicaSet=INFO6150-shard-0&authSource=admin&retryWrites=true'
mongoose.connect(url, {
  promiseLibrary: global.Promise,
  useNewUrlParser: true
}, (err) => {
  if (err) {
    console.log(err)
  } else {
    console.log('mongoose connected')
  }
});
mongoose.set('useFindAndModify', false)


/**
 * Adding body parser for handling request and response objects.
 */
app.use(bodyParser.urlencoded({
  extended: true
}));
app.use(bodyParser.json());

/**
 * Enabling CORS
 */
app.use(function (req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Methods", "GET, PUT, POST, DELETE");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, token");
  next();
});

/**
 * Initialize app
 */
let smartAppRoutes = require('./api/app');
smartAppRoutes(app);

app.listen(port);
console.log('smartApp RESTful API server started on: ' + port);