import { SmartAppService } from "./../services/smart-app.service";
import { Component, OnInit } from "@angular/core";
import { Observable } from "rxjs";
import { Router } from "@angular/router";
import { User } from "../models/user";

@Component({
  selector: "app-sign-up",
  templateUrl: "./sign-up.component.html",
  styleUrls: ["./sign-up.component.css"]
})
export class SignUpComponent implements OnInit {
  email: string;
  password: string;
  service: SmartAppService;
  passwordpass: string;
  sametxt: boolean;
  resultsss: boolean = false;
  emptytxt: boolean = false;
  createObservable: Observable<any>;
  routerLog: Router;
  exist: Boolean = false;
  show: boolean;

  textflag: boolean = false;


  constructor(
    private smartAppService: SmartAppService,
    private router: Router
  ) {
    this.routerLog = router;
    this.service = smartAppService;
  }

  ngOnInit() {}

  /**
   * This function in order to create new user account.
   */
  createNewUser() {

    if (this.passwordpass === undefined || this.password === undefined || this.email === undefined) {
      this.resultsss = false;
      this.show= false;
      this.textflag = true;
      return this.textflag;
    } else if( this.password !== this.passwordpass ) {
      // if (this.password !== this.passwordpass) {
        this.show = true;
        this.textflag = false;
       } 
      else {
        this.show = false;
        this.textflag = false;
        const body = {
          email: this.email,
          password: this.password
        };
        this.createObservable = this.service.createUser(body);
        this.createObservable.subscribe((res = 200) => {
          alert('Create Successfully!');
          this.routerLog.navigate(['login']);
          alert('New Account Created Successfully!');
        }, (err = 409) => {
          alert('Username has existed.');
          this.routerLog.navigate(['signup']);
          this.exist = true;
        })
      }
     }
    

  conformEmail() {
    
    const conform = /[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/;
    const result = conform.test(this.email);
    if (result === false) {
      this.resultsss = true;
      this.show = false;
    } else {
      this.resultsss = false;
    }
    return this.resultsss;
  }
}
