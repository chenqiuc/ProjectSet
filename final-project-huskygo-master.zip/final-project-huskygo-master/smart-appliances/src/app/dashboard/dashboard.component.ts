import { SmartAppService } from "./../services/smart-app.service";
import { Component, OnInit, Input } from "@angular/core";
import { SmartApp } from "../models/smartApp";
import { Subscription } from "rxjs";

@Component({
  selector: "app-dashboard",
  templateUrl: "./dashboard.component.html",
  styleUrls: ["./dashboard.component.scss"]
})
export class DashboardComponent implements OnInit {
  keywordInput: string;
  sharedKeywordSub: Subscription;
  appArr: Array<SmartApp> = [];
  tempArr: Array<SmartApp> = [];
  roomList: Array<String> = ["Living Room", "Bed Room", "Kitchen"];
  typeList: Array<String> = [
    "Ceiling Lamp",
    "TV",
    "Rice Cooker",
    "A/C",
    "Desk Lamp"
  ];
  appName: String;
  appType: String;
  roomType: String;

  ngOnInit() { }

  constructor(private smartAppService: SmartAppService) {
    this.appArr = smartAppService.getUserData();
    this.sharedKeywordSub = smartAppService.sharedKeyword$.subscribe(
      keyword => {
        this.keywordInput = keyword;
        console.log(this.keywordInput);

        if (this.appArr.length >= this.tempArr.length) {
          this.tempArr = [...this.appArr];
        } else {
          this.appArr = [...this.tempArr];
        }
        this.appArr = smartAppService.searchApp(this.appArr, this.keywordInput);
      }
    );
  }

  addApp() {
    let tempApp = new SmartApp(this.appName, this.appType, this.roomType);
    this.appArr = this.smartAppService.addApp(tempApp);
    this.appName = "";
    this.appType = "";
    this.roomType = "";
  }

  deleteApp(event) {
    this.appArr = this.smartAppService.deleteApp(event);
  }

  updateSetting(event) {
    this.appArr = this.smartAppService.updateSetting(event);
  }

  filterApp(event) {
    if (this.appArr.length >= this.tempArr.length) {
      this.tempArr = [...this.appArr];
    } else {
      this.appArr = [...this.tempArr];
    }

    let room = event.target.innerHTML;
    this.appArr = this.smartAppService.filterApp(this.appArr, room);
  }

  color01() {
    document.getElementById("all").parentElement.style.backgroundColor =
      "white";
    document.getElementById("bed").parentElement.style.backgroundColor =
      "#e7e9ee";
    document.getElementById("living").parentElement.style.backgroundColor =
      "#e7e9ee";
    document.getElementById("kitchen").parentElement.style.backgroundColor =
      "#e7e9ee";
    // document.getElementById("reset").parentElement.style.backgroundColor="#e7e9ee";
  }

  color02() {
    document.getElementById("bed").parentElement.style.backgroundColor =
      "white";
    document.getElementById("all").parentElement.style.backgroundColor =
      "#e7e9ee";
    document.getElementById("living").parentElement.style.backgroundColor =
      "#e7e9ee";
    document.getElementById("kitchen").parentElement.style.backgroundColor =
      "#e7e9ee";
    // document.getElementById("reset").parentElement.style.backgroundColor="#e7e9ee";
  }

  color03() {
    document.getElementById("living").parentElement.style.backgroundColor =
      "white";
    document.getElementById("bed").parentElement.style.backgroundColor =
      "#e7e9ee";
    document.getElementById("all").parentElement.style.backgroundColor =
      "#e7e9ee";
    document.getElementById("kitchen").parentElement.style.backgroundColor =
      "#e7e9ee";
    // document.getElementById("reset").parentElement.style.backgroundColor="#e7e9ee";
  }

  color04() {
    document.getElementById("kitchen").parentElement.style.backgroundColor =
      "white";
    document.getElementById("bed").parentElement.style.backgroundColor =
      "#e7e9ee";
    document.getElementById("living").parentElement.style.backgroundColor =
      "#e7e9ee";
    document.getElementById("all").parentElement.style.backgroundColor =
      "#e7e9ee";
    // document.getElementById("reset").parentElement.style.backgroundColor="#e7e9ee";
  }

  color05() {
    document.getElementById("reset").parentElement.style.backgroundColor =
      "white";
    document.getElementById("bed").parentElement.style.backgroundColor =
      "#e7e9ee";
    document.getElementById("living").parentElement.style.backgroundColor =
      "#e7e9ee";
    document.getElementById("kitchen").parentElement.style.backgroundColor =
      "#e7e9ee";
    // document.getElementById("all").parentElement.style.backgroundColor="#e7e9ee";
  }
}
