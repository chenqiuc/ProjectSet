import { SmartApp } from './../models/smartApp';
import { Component, OnInit, Input, EventEmitter, Output } from "@angular/core";
import { SmartAppService } from "../services/smart-app.service";

@Component({
  selector: "app-app-card",
  templateUrl: "./app-card.component.html",
  styleUrls: ["./app-card.component.scss"]
})
export class AppCardComponent implements OnInit {
  @Input() smartApp: any;
  @Input() configurationObj: any;
  @Output() updateEmit = new EventEmitter<any>();
  @Output() deleteEmit = new EventEmitter<any>()
  
  configuration: Object;
  tempObj: Object = {};
  tempApp: SmartApp;

  constructor() { }

  ngOnInit() {
    this.configuration = { ...this.smartApp.configuration };
  }


  recordUpdate(obj: Object) {
    this.tempObj[obj['key']] = obj['value'];
  }

  updateSetting(e) {
    this.tempApp = {...this.smartApp};
    this.tempApp.configuration = {...this.tempApp.configuration, ...this.tempObj}
    this.updateEmit.emit(this.tempApp);
  }

  refreshInput() {
    console.log('refreshInput called');
  }

  deleteApp(e) {
    let tempArr = e.target.id.split('-');
    let id = tempArr[tempArr.length - 1];
    this.deleteEmit.emit(id);
  }
}
