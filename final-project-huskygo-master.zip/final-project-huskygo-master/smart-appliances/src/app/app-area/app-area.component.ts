import { Component, OnInit, Input, Output, EventEmitter } from "@angular/core";
import { SmartApp } from "../models/smartApp";
import { SmartAppService } from "../services/smart-app.service";
@Component({
  selector: "app-app-area",
  templateUrl: "./app-area.component.html",
  styleUrls: ["./app-area.component.scss"]
})
export class AppAreaComponent implements OnInit {
  @Input() smartAppArr: Array<SmartApp>;
  @Output() passDeleteEmit = new EventEmitter<any>()
  @Output() passUpdateEmit = new EventEmitter<any>()

  renderArr: Array<SmartApp>;

  constructor() { }

  ngOnInit() { }

  deleteEmitPasser(event) {
    this.passDeleteEmit.emit(event);
  }

  updateEmitPasser(event) {
    this.passUpdateEmit.emit(event);
  }
  
}
