import { TasklistComponent } from "./tasklist/tasklist.component";
import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { DashboardComponent } from "./dashboard/dashboard.component";
import { PageNotFoundComponent } from "./page-not-found/page-not-found.component";
import { ProfileComponent } from "./profile/profile.component";
import { LoginPageComponent } from "./login-page/login-page.component";
import { SignUpComponent } from "./sign-up/sign-up.component";

const routes: Routes = [
  // { path: "", redirectTo: "/dashboard", pathMatch: "full" },
  { path: "", redirectTo: "/login", pathMatch: "full" },
  { path: 'login', component: LoginPageComponent},
  { path: 'signup', component: SignUpComponent},
  { path: "dashboard", component: DashboardComponent},
  { path: "tasklist", component: TasklistComponent },
  { path: "profile", component: ProfileComponent},
  { path: "**", component: PageNotFoundComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
