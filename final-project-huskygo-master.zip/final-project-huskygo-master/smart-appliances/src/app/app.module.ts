import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { FormsModule } from '@angular/forms';
import { UiSwitchModule } from 'ngx-toggle-switch';
import { ElModule } from 'element-angular'

import 'element-angular/theme/index.css';


import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { SmartAppService } from "./services/smart-app.service";
import { HttpClientModule } from "@angular/common/http";
import { AppCardComponent } from "./app-card/app-card.component";
import { NavBarComponent } from "./nav-bar/nav-bar.component";
import { AppAreaComponent } from "./app-area/app-area.component";
import { FooterComponent } from "./footer/footer.component";
import { DashboardComponent } from "./dashboard/dashboard.component";
import { TasklistComponent } from "./tasklist/tasklist.component";
import { PageNotFoundComponent } from "./page-not-found/page-not-found.component";
import { ProfileComponent } from "./profile/profile.component";
import { LoginPageComponent } from './login-page/login-page.component';
import { SignUpComponent } from './sign-up/sign-up.component';

@NgModule({
  declarations: [
    AppComponent,
    AppCardComponent,
    NavBarComponent,
    AppAreaComponent,
    FooterComponent,
    DashboardComponent,
    TasklistComponent,
    PageNotFoundComponent,
    ProfileComponent,
    LoginPageComponent,
    SignUpComponent,
    
  ],
  imports: [BrowserModule, AppRoutingModule, HttpClientModule, FormsModule, UiSwitchModule, ElModule.forRoot()],
  providers: [SmartAppService],
  bootstrap: [AppComponent]
})
export class AppModule { }
