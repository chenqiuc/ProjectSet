import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-profile",
  templateUrl: "./profile.component.html",
  styleUrls: ["./profile.component.scss"]
})
export class ProfileComponent implements OnInit {
  constructor() { }

  ngOnInit() { }

  userName:String = 'admin@husky.neu.edu';
  password: String = 'admin';
  registeredDate:Date = new Date()

  // profileDetail: Profile;

  // constructor(profileService: ProfileService){
  //   this.profileDetail = profileService.showDetail();
  
  //   this.userName = profileService.showDetail().userName;
  //   this.password = profileService.showDetail().password;
  //   this.registeredDate = profileService.showDetail().registeredDate;
  // }
  

}
