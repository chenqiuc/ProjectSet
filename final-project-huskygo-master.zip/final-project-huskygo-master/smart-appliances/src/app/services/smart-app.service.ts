import { UserData } from "./../models/userData";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { SmartApp } from "./../models/smartApp";
import { Injectable } from "@angular/core";
import { Observable, Subject } from "rxjs";

@Injectable({
  providedIn: "root"
})
export class SmartAppService {
  private loginObservable: Observable<any>;

  private userDataObservable: Observable<UserData>;
  private deleteAppObservable: Observable<UserData>;
  private addAppObservable: Observable<UserData>;
  private updateSettingObservable: Observable<UserData>;

  private sharedKeyword: Subject<string> = new Subject<string>();

  getObservable: Observable<any[]>;
  createObservable: Observable<any>;
  token: String;
  userArr: Array<any>;
  headers: HttpHeaders = new HttpHeaders();
  useremial = "admin@husky.neu.edu";


  constructor(private httpClient: HttpClient) { }

  loginUser(body) {
    this.loginObservable = this.httpClient.post('http://localhost:7777/users', body);
    // this.token = this.loginObservable['token'];

    return this.loginObservable;
  }

  createUser(body) {
    this.createObservable = this.httpClient.post('http://localhost:7777/users/user', body);
    // this.createObservable.subscribe((res) => { console.log(res); }, (err) => { console.log(err); });
    return this.createObservable;
  }

  get sharedKeyword$() {
    return this.sharedKeyword.asObservable();
  }

  addSharedKeyword(data: string) {
    this.sharedKeyword.next(data);
  }

  getUserData(): Array<SmartApp> {
    let appArr = [];
    this.headers = this.headers.append("token", this.useremial);
    this.userDataObservable = this.httpClient.get<UserData>(
      "http://localhost:7777/userdata"
    );
    this.userDataObservable.subscribe(
      res => {
        let tempArr: Array<SmartApp> = res[0].smartapps;
        for (let app of tempArr) {
          appArr.push(app);
        }
      },
      err => {
        console.log(err);
      }
    );
    return appArr;
  }

  addApp(app: SmartApp) {
    console.log(app);
    let appArr = [];
    let body = { smartApp: app };
    this.addAppObservable = this.httpClient.post<UserData>(
      `http://localhost:7777/userdata`, body
    );
    this.addAppObservable.subscribe(
      res => {
        let tempArr: Array<SmartApp> = res[0].smartapps;
        for (let app of tempArr) {
          appArr.push(app);
        }
      },
      err => {
        console.log(err);
      }
    );
    return appArr;
  }

  updateSetting(app: SmartApp) {
    let appArr = [];
    let tempid = app.id;
    let body = { smartApp: app };
    this.updateSettingObservable = this.httpClient.put<UserData>(
      `http://localhost:7777/userdata/smartapps/${tempid}`,
      body
    );
    this.updateSettingObservable.subscribe(
      res => {
        let tempArr: Array<SmartApp> = res[0].smartapps;
        for (let app of tempArr) {
          appArr.push(app);
        }
      },
      err => {
        console.log(err);
      }
    );
    return appArr;
  }

  deleteApp(id: String): Array<SmartApp> {
    let appArr = [];
    const tempURL = `http://localhost:7777/userdata/smartapps/${id}`;

    this.deleteAppObservable = this.httpClient.delete<UserData>(tempURL);
    this.deleteAppObservable.subscribe(
      res => {
        let tempArr: Array<SmartApp> = res[0].smartapps;
        for (let app of tempArr) {
          appArr.push(app);
        }
      },
      err => {
        console.log(err);
      }
    );
    return appArr;
  }

  filterApp(appArr: Array<SmartApp>, room: String): Array<SmartApp> {
    let tempArr = [];
    if (room === "All") {
      tempArr = [...appArr];
    } else {
      for (let app of appArr) {
        if (app.room === room) {
          tempArr.push(app);
        }
      }
    }
    return tempArr;
  }

  searchApp(appArr: Array<SmartApp>, keyword: string): Array<SmartApp> {
    let tempArr = [];
    console.log(`keyword ${keyword}`);
    console.log(appArr);
    for (let app of appArr) {
      let name = app.name.toUpperCase();
      let key = keyword.toUpperCase();
      if (name.includes(key)) {
        tempArr.push(app);
      }
    }
    return tempArr;
  }
}


