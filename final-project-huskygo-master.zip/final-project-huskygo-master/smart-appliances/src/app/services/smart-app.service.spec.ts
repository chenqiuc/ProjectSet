import { TestBed } from '@angular/core/testing';

import { SmartAppService } from './smart-app.service';

describe('SmartAppService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SmartAppService = TestBed.get(SmartAppService);
    expect(service).toBeTruthy();
  });
});
