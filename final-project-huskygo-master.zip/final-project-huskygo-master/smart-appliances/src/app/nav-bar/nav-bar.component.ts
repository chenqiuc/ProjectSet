import { SmartAppService } from "./../services/smart-app.service";
import { Component, OnInit, Output, EventEmitter } from "@angular/core";
import { ElNotificationService, ElMessageService } from 'element-angular';

@Component({
  selector: "app-nav-bar",
  templateUrl: "./nav-bar.component.html",
  styleUrls: ["./nav-bar.component.scss"]
})
export class NavBarComponent implements OnInit {

  keyword: string = "";

  constructor(private smartAppService: SmartAppService) { }

  ngOnInit() { }

  searchFun() {
    this.smartAppService.addSharedKeyword(this.keyword);
  }
}
