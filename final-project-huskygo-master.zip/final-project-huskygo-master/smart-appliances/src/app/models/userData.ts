import { SmartApp } from './smartApp';


export class UserData {
  _id: String;
  useremail: String;
  smartapps: Array<SmartApp>
}
