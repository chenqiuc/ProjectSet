export class SmartApp {
  id: Object;
  name: String;
  type: String;
  room: String;
  status: Boolean = false;
  img: String;
  configuration: Object;
  tasklist: Array<object> = [];

  constructor(name: String, type: String, room: String) {
    this.name = name;
    this.type = type;
    this.room = room;
    this.status = false;

    switch (type) {
      case "Ceiling Lamp":
        this.img = "../../assets/ceiling_lamp.jpg";
        this.configuration = {
          Brightness: "80"
        };
        break;
      case "Desk Lamp":
        this.img = "../../assets/desk_lamp.jpg";
        this.configuration = {
          Brightness: "80"
        };
        break;
      case "TV":
        this.img = "../../assets/tv.jpg";
        this.configuration = {
          Brightness: "80"
        };
        break;
      case "Rice Cooker":
        this.img = "../../assets/rice_cooker.jpg";
        this.configuration = {
          Mode: "White Rice",
          "Keep Warm": "True"
        };
        break;
      case "A/C":
        this.img = "../../assets/air_conditioner.jpg";
        this.configuration = {
          Mode: "Cooling",
          Temperature: "70F"
        };
        break;
    }
  }
}
