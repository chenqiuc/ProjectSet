import { Component, OnInit } from "@angular/core";
import { SmartAppService } from "../services/smart-app.service";
import { Router } from "@angular/router";
import { Observable } from "rxjs";

@Component({
  selector: "app-login-page",
  templateUrl: "./login-page.component.html",
  styleUrls: ["./login-page.component.css"]
})
export class LoginPageComponent implements OnInit {
  email: string;
  password: string;
  service: SmartAppService;
  txtEmpity: Boolean = false;
  routertoMain: Router;

  loginobservable: Observable<any>;
  show: boolean = false;
  empty: boolean = false;
  testresult: boolean = false;

  constructor(
    private smartAppService: SmartAppService,
    private router: Router
  ) {
    this.service = smartAppService;
    this.routertoMain = router;

    console.log(this.email);
    console.log(this.password);
  }

  ngOnInit() {}

  loginUser() {
    const body = {
      email: this.email,
      password: this.password
    };

    if (this.password === undefined || this.email === undefined) {
      this.show = false;
      this.empty = true;
    } else {
      this.empty = false;
      this.loginobservable = this.service.loginUser(body);
      this.loginobservable.subscribe(
        res => {
          console.log(res);
          this.routertoMain.navigate(["dashboard"]);
        },
        err => {
          console.log(err);
          alert("login failed");
          this.show = true;
        }
      );
    }
  }

  /**
   * This function is used to confirm email context.
   */
  conformEmail() {
    const conform = /[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/;
    const result = conform.test(this.email);
    if (!result) {
      this.testresult = true;
    } else {
      this.testresult = false;
    }
    return this.testresult;
  }
}
