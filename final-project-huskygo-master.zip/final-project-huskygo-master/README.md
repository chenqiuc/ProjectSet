# Smart Appliances Management Portal 
__🐾 By Team HuskyGo 🐾__

</br>

## User Story:

### Login & SignUp Account:
+ As a user, you will start with a login page
+ As a user, you can log in this system with `UserName` and `Password` created before
+ As a user, you can sign up a new account


### Manage Appliances:
+ As a user, you will have a view of all `registered appliances` on `dashboard` page
+ As a user, you can filter appliances in each room, by click `room label` on side bar
+ As a user, you can sorting appliances by `appliances type`, `working status`, etc.,

#### Connect New Appliance:
+ As a user, you can be able to connect new smart appliances

#### Control Appliance:
+ As a user, you can check connected appliances’ details with `details modal` by clicking each appliances' card
+ As a user, you can full controled any connected appliances functions, such like `working time`, `brightness`, `temperature` etc.,
+ As a user, you can assign `special task`, such like "start to cooking rice at 4:00PM"
+ As a user, you will get `notification email` once your appliances start `special task`

#### Remove Appliance:
+ As a user, you can remove any connected appliances


### Smart Interaction:
+ As a user, you will get `smart suggestions` from the application to make your life more comfortable
   _For example: when you watching TV with a light at bedroom, if you turn down the brightness of light on the portal, the portal will suggest whether you would like to turn the brightness of TV in order to protect your eyes_

</br>

## Domain Driven Diagram:

### Whole Picture of Application Diagram:
<img src="design/INFO6150_HuskyGo_SmartAppliancesManagementPortal_ObjectModel.svg" width=1000px/>

</br>

### Use Case Diagram:
<img src="design/Electric Appliance Project Diagram.svg" width=800px/>
